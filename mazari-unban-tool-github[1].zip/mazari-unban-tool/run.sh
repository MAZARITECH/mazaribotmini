#!/bin/bash
clear
echo -e "\e[92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "      🔓 M A Z A R I   U N B A N   T O O L"
echo -e "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\e[0m"

echo ""
echo -e "📢 پہلے ہمارے واٹس ایپ چینل کو جوائن کریں:"
echo "➡️ https://whatsapp.com/channel/0029Vb6GUj8BPzjOWNfnhm1B"

echo ""
read -p '✅ فالو کرنے کے بعد Enter دبائیں...' enterKey

echo ""
echo -e "🌐 زبان منتخب کریں:"
echo "1. English"
echo "2. اردو"
echo "3. فارسی"
echo "4. عربی"
read -p '🔢 اپنی زبان کا نمبر درج کریں: ' lang

echo ""
read -p '📞 اپنا WhatsApp نمبر درج کریں: + ' number

echo ""
echo -e "📨 جنریٹ کی جا رہی ہیں رپورٹس...\n"

case $lang in
  1)
    echo "✅ Report 1: Hello WhatsApp Support, I am facing an issue... (English)"
    echo "✅ Report 2: My number was banned mistakenly... (English)"
    ;;
  2)
    echo "✅ رپورٹ 1: محترم واٹس ایپ ٹیم، میرا نمبر غلطی سے بین ہو گیا ہے... (اردو)"
    echo "✅ رپورٹ 2: برائے مہربانی میرے نمبر پر دوبارہ غور کریں... (اردو)"
    ;;
  3)
    echo "✅ گزارش 1: شماره من اشتباهی بن شده است... (فارسی)"
    echo "✅ گزارش 2: لطفا حساب من را بررسی کنید... (فارسی)"
    ;;
  4)
    echo "✅ تقرير 1: تم حظر رقمي عن طريق الخطأ... (عربي)"
    echo "✅ تقرير 2: الرجاء مراجعة حسابي... (عربي)"
    ;;
  *)
    echo "⚠️ غلط انتخاب، دوبارہ کوشش کریں!"
    ;;
esac

echo ""
echo -e "\e[92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "      🎥 YouTube: https://youtube.com/@mazari_technical304"
echo -e "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\e[0m"
