# 🛠️ Mazari Unban Tool

This tool is created by **Mazari Technical** to help recover banned WhatsApp numbers.

### 🔗 Follow First:
👉 **WhatsApp Channel**: [Join Now](https://whatsapp.com/channel/0029Vb6GUj8BPzjOWNfnhm1B)  
🎥 **YouTube**: [Mazari Technical](https://youtube.com/@mazari_technical304)

### 🚀 Usage in Termux:

```bash
pkg update -y && pkg upgrade -y
pkg install git -y
pkg install unzip -y
pkg install bash -y

git clone https://github.com/YourUsername/mazari-unban-tool
cd mazari-unban-tool
bash run.sh
```

---
🔓 Tool will allow language selection and generate 2+ sample reports for unban requests.
